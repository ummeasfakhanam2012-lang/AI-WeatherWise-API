# GitHub Upload Notes

1. Upload the project source (`src/`) together with these root files.
2. Keep `.env` local only. Never commit real API keys or database credentials.
3. Use `.env.example` as the template for local configuration.
4. Run `npm install` after cloning.
5. Run `npm run dev` for development or `npm start` for production.
